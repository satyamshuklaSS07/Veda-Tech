# Veda Tech: Business & Services Website

A responsive multi-section website for a technology and digital-services organization, with an optional secure Node.js backend.

## Objective
Practice multi-section website design with responsive layout, reusable components, JavaScript interactions, SEO basics and a professional UI.

## Tools
HTML5, CSS3, JavaScript, Node.js (Express), Git, GitHub

## Features
- Homepage with search, trending chips, category cards and featured internships
- Sections: Home, About, Find your track, Programs, Internship & Training, IT & Digital Services, Certification, Reviews, FAQ, Contact
- Reusable cards built from data arrays (`P`, `S`, `F` in `index.html`)
- Track finder quiz, program search and filter, FAQ search, apply popup, reviews, theme toggle, scroll progress bar
- Responsive navigation, mobile layout, keyboard focus styles, reduced-motion support
- SEO: title, meta description, heading structure, meaningful `#section` URLs

## Configure
Open `index.html` and edit the `CFG` object near the top of the script:
```js
const CFG={email:"you@example.com",phone:"+91XXXXXXXXXX",whatsapp:"91XXXXXXXXXX",location:"Your city"};
```
Email, phone and location appear in Contact and the footer. The WhatsApp button shows only when `whatsapp` is set.

## Run with backend
```bash
npm install
npm start        # http://localhost:3000
```
Applications and contact messages are saved to `data/applications.jsonl` and `data/messages.jsonl`.
Without the backend (for example GitHub Pages), forms fall back to a prefilled email link.

## Security measures
- Server: Helmet security headers with a strict Content-Security-Policy, rate limiting (20 requests per 15 minutes per IP), 10 KB body limit, input cleaning and validation, honeypot field against bots, no stack traces, only `index.html` is served (server code and data files cannot be downloaded)
- Browser: all user text is escaped before display, input length limits, send cooldown
- No security is absolute. Keep dependencies updated (`npm audit`), use HTTPS hosting, and never commit `.env` or `data/`

## Deploy
- **Static only:** GitHub Pages (Settings, Pages, branch `main`, `/root`)
- **With backend:** any Node host such as Render or Railway (build: `npm install`, start: `npm start`)

```bash
git init && git add . && git commit -m "Veda Tech website"
git branch -M main
git remote add origin https://github.com/<username>/veda-tech-website.git
git push -u origin main
```

## Notes
Veda Tech is a sample brand for a learning project; program details are illustrative. Use only accurate public information and do not claim certifications or approvals you do not have.
